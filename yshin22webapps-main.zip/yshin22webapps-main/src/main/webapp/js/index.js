console.log("js/index.js script loaded");
